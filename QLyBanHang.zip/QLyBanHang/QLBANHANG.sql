create database QUANLYBH
use QUANLYBH
create table BH1(
stt int identity(1,1),
tenHang nvarchar(30),
donGia float ,
);
create table DH(
stt int identity(1,1),
tenHang nvarchar(30),
soLuong int,
donGia float ,
thanhTien float,
);



