﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLyBH
{
    
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        //SqlDataAdapter adapDl;
        //DataTable dt;
        SqlDataAdapter adapDgv1;
        DataTable dtDgv1;
        SqlDataAdapter adapDgv2;
        DataTable dtDgv2;
        string sql = "Data Source=LAPTOP-GIDOGASR\\SQLEXPRESS;Initial Catalog=QUANLYBH;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(sql);
            con.Open();

            adapDgv1 = new SqlDataAdapter("select row_number() over (order by stt) as 'STT' ,tenHang as 'Tên Hàng',donGia as 'Đơn Giá' from BH1", con);
            dtDgv1 = new DataTable();
            dtDgv1.Rows.Clear();
            adapDgv1.Fill(dtDgv1);
            dataGridView1.DataSource = dtDgv1;

            adapDgv2 = new SqlDataAdapter("select row_number() over (order by stt) as 'STT' ,tenHang as 'Tên Hàng',soLuong as 'Số Lượng',donGia as 'Đơn Giá',thanhTien as 'Thành Tiền' from DH", con);
            dtDgv2 = new DataTable();
            dtDgv2.Rows.Clear();
            adapDgv2.Fill(dtDgv2);
            dataGridView2.DataSource = dtDgv2;
            cmd = new SqlCommand();
            cmd.Connection = con;
        }

        private void btnTao_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("delete from DH", con);
            cmd.ExecuteNonQuery();
            dtDgv2.Rows.Clear();
            adapDgv2.Fill(dtDgv2);
            txtTongTien.Text = "";
            txtTen.Text = "";
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string tenHang = dataGridView1.SelectedRows[0].Cells["Tên Hàng"].Value.ToString();
                int soLuong = (int)numericUpDown1.Value;
                float donGia = Convert.ToSingle( dataGridView1.SelectedRows[0].Cells["Đơn Giá"].Value.ToString());
                float thanhTien = soLuong * donGia;
    
            string query = "INSERT INTO DH (tenHang, soLuong, donGia, thanhTien) VALUES (N'" + tenHang + "', " + soLuong + ", " + donGia + ", " + thanhTien + ")";
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
                dtDgv2.Rows.Clear();
                adapDgv2.Fill(dtDgv2);
            }
        }
        private void cbTheLoai_SelectedIndexChanged(object sender, EventArgs e)
        {
            adapDgv1 = new SqlDataAdapter("select row_number() over (order by stt) as 'STT', tenHang as 'Tên Hàng',donGia as 'Đơn Giá' from BH1 where theLoai = N'" + cbTheLoai.Text + "' group by stt,tenHAng,donGia,theLoai", con);
            dtDgv1.Clear();
            adapDgv1.Fill(dtDgv1);
            dataGridView1.DataSource = dtDgv1;
            switch (cbTheLoai.SelectedIndex)
            {
                case 0:
                    {
                        labelTheLoai.Text = "Đồ uống";
                        
                        
                       
                        break;
                    }
                case 1:
                    {
                        labelTheLoai.Text = "Bột mì";
                        break; 
                    }
                case 2:
                    {
                        labelTheLoai.Text = "Gia vị";
                        break;
                    }
                case 3:
                    {
                        labelTheLoai.Text = "Sữa";
                        break;
                    }
                case 4:
                    {
                        labelTheLoai.Text = "Đường";
                        break;
                    }
                case 5:
                    {
                        labelTheLoai.Text = "Rau củ";
                        break;
                    }
                case 6:
                    {
                        labelTheLoai.Text = "Thịt";
                        break;
                    }
                    
            }
        }

        private void cbTheLoai_SelectionChangeCommitted(object sender, EventArgs e)
        {
           // CategoryAttribute obj = cbTheLoai.SelectedItem as CategoryAttribute;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Assuming the primary key column in DH is 'id'
                int select = dataGridView2.SelectedRows[0].Index;
                int id = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["STT"].Value);

                // Remove the selected row from the DataGridView
                dataGridView2.Rows.RemoveAt(select);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {   
            float TongTien = 0;
            
            for (int i=0; i < dtDgv2.Rows.Count; i++)
            {
                TongTien += float.Parse(dtDgv2.Rows[i]["Thành Tiền"].ToString());
            }
          txtTongTien.Text = TongTien.ToString();
        }

        private void đổiMàuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                contextMenuStrip1.SourceControl.BackColor = dlg.Color;
            }
        }
    }
}
