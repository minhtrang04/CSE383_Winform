﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QlyBanHang
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adapDl;
        SqlDataReader dr;
        DataTable dt;
        string sql = "Data Source=LAPTOP-GIDOGASR\\SQLEXPRESS;Initial Catalog=QLBH;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(sql);
            con.Open();
            adapDl = new SqlDataAdapter("select row_number() over (order by stt) as'STT', tenHang as 'Tên hàng',soLuong as 'Số lượng',donGia as 'Đơn giá',thanhTien as 'Thành tiền' from BH", con);
            dt = new DataTable();
            adapDl.Fill(dt);
            dataGridView1.Rows.Clear();
            dataGridView1.DataSource = dt;

            cmd = new SqlCommand();
            cmd.Connection = con;
        } 
        private void btnTaoDon_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("delete from BH", con);
            cmd.ExecuteNonQuery();
            dt.Rows.Clear();
            adapDl.Fill(dt);
            cbTenHang.Text = "";
            txtDonGia.Text = "";
            txtTongTien.Text = "";
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            int num = int.Parse(numSoLuong.Value.ToString());
            int donGia = int.Parse(txtDonGia.Text);
            float thanhTien = num * donGia;

             cmd = new SqlCommand("insert into BH values (N'" + cbTenHang.Text+ "','" + num + "','" + txtDonGia.Text + "','" + thanhTien + "')", con);
             cmd.ExecuteNonQuery();
             dt.Rows.Clear();
             adapDl.Fill(dt);

           // dt.Rows.Add(stt,cbTenHang.Text,num,txtDonGia.Text,thanhTien);
           
        } 
      
        private void cbTenHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbTenHang.SelectedIndex)
            {
                case 0:
                    {
                        txtDonGia.Text = "15000";
                        break;
                    }
                case 1:
                    {
                        txtDonGia.Text = "18000";
                        break;
                    }
                case 2:
                    {
                        txtDonGia.Text = "10000";
                        break;
                    }
                case 3:
                    {
                        txtDonGia.Text = "20000";
                        break;
                    }
                case 4:
                    {
                        txtDonGia.Text = "12000";
                        break;
                    }
                case 5:
                    {
                        txtDonGia.Text = "18000";
                        break;
                    }
            }

        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {

            float sum = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                sum += float.Parse(dt.Rows[i][4].ToString());
            }
            txtTongTien.Text = sum.ToString();
        }
        int dongHt = -1;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {     dongHt = e.RowIndex;
             if (dongHt >= 0 && dataGridView1.Rows.Count > dongHt)
             {
                 int num = int.Parse(numSoLuong.Value.ToString());
                 cbTenHang.Text = dataGridView1.Rows[dongHt].Cells[1].Value.ToString();
                 num = int.Parse(dataGridView1.Rows[dongHt].Cells[2].Value.ToString());
                 txtDonGia.Text = dataGridView1.Rows[dongHt].Cells[3].Value.ToString();
                 txtTongTien.Text = dataGridView1.Rows[dongHt].Cells[4].Value.ToString();
             }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           /* int stt = int.Parse(dataGridView1.Rows[dongHt].Cells[0].Value.ToString());
               cmd = new SqlCommand("delete from BH where stt='"+stt+"'", con);
                cmd.ExecuteNonQuery();
                dt.Rows.Clear();
                adapDl.Fill(dt);
                dataGridView1.DataSource = dt;*/
                if(dongHt >= 0 && dataGridView1.Rows.Count > dongHt)
            {
                dataGridView1.Rows.RemoveAt(dongHt);
            }
        }

        private void đỏiMàuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = colorDialog1.ShowDialog();
            if(result== DialogResult.OK)
            {
                contextMenuStrip1.SourceControl.BackColor = colorDialog1.Color;
                // contextMenuStrip1.SourceControl.ForeColor = colorDialog1.Color;
            }
        }
    }
}
