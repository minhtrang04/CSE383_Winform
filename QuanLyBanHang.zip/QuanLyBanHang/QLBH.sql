create database QLBH
use QLBH
create table BH(
stt int identity(1,1),
tenHang nvarchar(30),
soLuong int ,
donGia float,
thanhTien float,
);
